try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const { px } = __$$app$$__.__globals__;
        const logger = Logger.getLogger("clover");
        let val, hour, minute, dial, timedX, timedY, groupX, groupY, hour_am_dec, hour_pm_dec, hour_am, hour_pm, sunriseX, sunriseY, sunsetX, sunsetY;
        const dialOffset = -210;
        const dialShift = -75;
        const dialSize = 900;
		const sunIconSize = 50;
		const r2 = dialSize / 2;
		const minDegrees = 0;
		const hourDegress = -6;
		const secDegres = 0;
		const otstup = 0;
		const half = 240;
		const const_group_radius = 120;
		const const_dig_width = 28;
		const const_dig_height = 44;
		const const_angle_start_rotate = 100;
		const const_angle_stop_rotate = 280;
		const const_dig_hour_radius = 200;
		const const_dig_min_radius = 205;
		const const_dig_sec_radius = 194;
		const constSunIcon = 200;
		const rOffset = 15;
		//const const_radian = Math.PI / 180;
		const timeFormat = hmSetting.getTimeFormat();
		
		var minStr = 0;
		var timeSensor, weatherSensor, weatherData, tideData, tideDataElement, sunrise, sunset;
		let sunriseIcon, sunsetIcon;
		
		let offsetX = 120;
		let offsetY = 240;
		let normal_minStr =''
		let idle_minStr =''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''		
        let normal_analog_clock_time_pointer_minute = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = const_dig_width;
        let normal_hour_TextCircle_img_height = const_dig_height;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 8;
        let normal_timerTextUpdate = undefined;
		let idle_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = const_dig_width;
        let normal_minute_TextCircle_img_height = const_dig_height;
        let normal_digital_clock_img_time_second = ''	
		let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = const_dig_width;
        let normal_second_TextCircle_img_height = const_dig_height;
		let groupAll = '';
		let Button_1 = ''

		var angle1 = 0;
		var sunriseAngle = 0;
		var sunsetAngle = 0;
		
		function loadSettings() {			
			if (hmFS.SysProGetInt('minstr_spotlight') === undefined) {
				minStr = 0;
				hmFS.SysProSetInt('minstr_spotlight', minStr);
			} else {
				minStr = hmFS.SysProGetInt('minstr_spotlight');
			};
		};		
		
		function switchMinStr(increment = true) {							 
			if (increment) {
				minStr = (minStr + 1) % 4;
				hmFS.SysProSetInt('minstr_spotlight', minStr);
				vibro();
			};
			//hmUI.showToast({text: parseInt(minStr).toString()});
		};	
				
        function computeXy(a) {
            const timeFormat = hmSetting.getTimeFormat();
            hour = a.hour;
            minute = a.minute;
			hour_am_dec = minStr * 2 + 2;
			hour_pm_dec = hour_am_dec + 1;
			hour_am = hour_am_dec + '.png';
			hour_pm = hour_pm_dec + '.png';
            if (hour > 12) {
                if (timeFormat == 1) {
                    //dial.setProperty(hmUI.prop.MORE, { src: "3.png" });
					dial.setProperty(hmUI.prop.MORE, { src: `${hour_pm}` });
                } else {
                    dial.setProperty(hmUI.prop.MORE, { src: `${hour_am}` });
					//dial.setProperty(hmUI.prop.MORE, { src: "2.png" });
                }
            } else {
                //dial.setProperty(hmUI.prop.MORE, { src: "2.png" });
				dial.setProperty(hmUI.prop.MORE, { src: `${hour_am}` });
            }
            timedX = dialOffset + (dialOffset + dialShift) * Math.sin(((hour + minute / 60) * Math.PI) / 6);
            timedY = dialOffset - (dialOffset + dialShift) * Math.cos(((hour + minute / 60) * Math.PI) / 6);
            dial.setProperty(hmUI.prop.MORE, { x: timedX, y: timedY });
        };	
		
		
		// function toRadian (degree) {
			// return degree * (Math.PI / 180);
		// };
		
		function toDegree (radian) {
		  return radian * (180 / Math.PI);
		};		

		// vibrate function

		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let timer_StopVibrate = null;

		function vibro(scene = 28) {
		  let stopDelay = 200;
		  stopVibro();
		  vibrate.stop();
		  vibrate.scene = scene;
		  if(scene < 23 || scene > 25) stopDelay = 1220;
		  vibrate.start();
		  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibro, {});
		}

		function stopVibro(){
		  vibrate.stop();
		  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

		// end vibrate function
		
		// repeat alerts
		function repeat_alerts() {
		  let hourEnd = false;
		  if(timeSensor.minute == 0) {
			hourEnd = true;
			vibro(5);
		  }
		};

		// end repeat alerts	

		function getSunDetails (we) {
			weatherData = we.getForecastWeather();		
			tideData = weatherData.tideData;
			tideDataElement = tideData.data[0];
			sunrise = tideDataElement.sunrise;
			sunset = tideDataElement.sunset;			
		};
		
		function setSunIcons (a) {
			const rOffsetSun = sunIconSize / 2 - rOffset;
			let sunriseHour = sunrise.hour;
			let sunsetHour = sunset.hour;
			sunriseIcon.setProperty(hmUI.prop.VISIBLE, false);
			sunsetIcon.setProperty(hmUI.prop.VISIBLE, false);
			
			if (timeFormat == 1) {
				if (sunriseHour > 12) sunriseHour = sunriseHour - 12;
				if (sunsetHour > 12) sunsetHour = sunsetHour - 12;
			};
			sunriseAngle = sunriseHour * 30 + (sunrise.minute / 2);
			sunsetAngle = sunsetHour * 30 + (sunset.minute / 2);
						
			let x1 = timedX + r2;
			let y1 = timedY + r2;
			
			sunriseX = x1 + (r2 + rOffsetSun) * Math.sin(sunriseAngle * Math.PI / 180) - sunIconSize / 2;
			sunriseY = y1 - (r2 + rOffsetSun) * Math.cos(sunriseAngle * Math.PI / 180) - sunIconSize / 2;
			
			sunsetX = x1 + (r2 + rOffsetSun) * Math.sin(sunsetAngle * Math.PI / 180) - sunIconSize / 2;
			sunsetY = y1 - (r2 + rOffsetSun) * Math.cos(sunsetAngle * Math.PI / 180) - sunIconSize / 2;
			
			if (a.hour > 12) {
				if (sunrise.hour > 12) {
					sunriseIcon.setProperty(hmUI.prop.MORE, { x: sunriseX, y: sunriseY });
					sunriseIcon.setProperty(hmUI.prop.VISIBLE, true);
				};
				if (sunset.hour > 12) {
					sunsetIcon.setProperty(hmUI.prop.MORE, { x: sunsetX, y: sunsetY });
					sunsetIcon.setProperty(hmUI.prop.VISIBLE, true);
				};
			} else {
				if (sunrise.hour < 12) {
					sunriseIcon.setProperty(hmUI.prop.MORE, { x: sunriseX, y: sunriseY });
					sunriseIcon.setProperty(hmUI.prop.VISIBLE, true);
				};
				if (sunset.hour < 12) {
					sunsetIcon.setProperty(hmUI.prop.MORE, { x: sunsetX, y: sunsetY });
					sunsetIcon.setProperty(hmUI.prop.VISIBLE, true);
				};
			};
			
			//sunriseIcon.setProperty(hmUI.prop.MORE, { x: sunriseX, y: sunriseY });
			//sunsetIcon.setProperty(hmUI.prop.MORE, { x: sunsetX, y: sunsetY });
		};
	
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();
				if (!weatherSensor) weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				
				getSunDetails (weatherSensor);
				
			    dial = hmUI.createWidget(hmUI.widget.IMG, { x: dialOffset, y: dialOffset, w: dialSize, h: dialSize, src: "2.png", show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD });
				
				sunriseIcon = hmUI.createWidget(hmUI.widget.IMG, { x: dialOffset, y: dialOffset, w: sunIconSize, h: sunIconSize, src: "sunrise.png", show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD });
				sunsetIcon = hmUI.createWidget(hmUI.widget.IMG, { x: dialOffset, y: dialOffset, w: sunIconSize, h: sunIconSize, src: "sunset.png", show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD});
				
				// vibration when connecting or disconnecting

				function checkConnection() {
				  console.log('checkConnection()');
				  hmBle.removeListener;
				  hmBle.addListener(function (status) {
					if(!status) {
					  hmUI.showToast({text: "Связь потеряна"});
					  vibro(9);
					}
					if(status) {
					  hmUI.showToast({text: "Связь восстановлена"});
					  vibro(0);
					}
				  });
				}

				// end vibration when connecting or disconnecting
		
				
				const deviceInfo = hmSetting.getDeviceInfo();
				timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
					getSunDetails (weatherSensor);
					repeat_alerts();
					computeXy(timeSensor);
					setSunIcons(timeSensor);
					text_update();
				});		
		
			
				normal_minStr = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: "min.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
				
/*                 idle_minStr = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: "5.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD,
                });		 */		
  
			
				normal_minute_TextCircle_ASCIIARRAY[0] = 'dig_s_0.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[1] = 'dig_s_1.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[2] = 'dig_s_2.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[3] = 'dig_s_3.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[4] = 'dig_s_4.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[5] = 'dig_s_5.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[6] = 'dig_s_6.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[7] = 'dig_s_7.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[8] = 'dig_s_8.png';  // set of images with numbers
				normal_minute_TextCircle_ASCIIARRAY[9] = 'dig_s_9.png';  // set of images with numbers

				//start of ignored block
				for (let i = 0; i < 2; i++) {
				  normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 240 - normal_minute_TextCircle_img_width / 2,
					pos_y: 240 - 222,
					src: 'dig_s_0.png',
					show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				  });
				  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
				};
				//end of ignored block	
				
				groupAll = hmUI.createWidget(hmUI.widget.GROUP, {
				  x: 120,
				  y: 240,
				  w: 240,
				  h: 240,
				});
				
				normal_clover_pic = groupAll.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'clover1.png',
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
				
				idle_clover_pic = groupAll.createWidget(hmUI.widget.IMG, {
				  x: 0,
				  y: 0,
				  src: 'clover2.png',
				  show_level: hmUI.show_level.ONLY_AOD,
				});
				
				normal_weather_image_progress_img_level = groupAll.createWidget(hmUI.widget.IMG_LEVEL, {
				  x: 200 - 120,
				  y: 392 - 240,
				  image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
				  image_length: 29,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});

 				normal_temperature_current_text_img = groupAll.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 288 - 120,
				  y: 340 - 240,
				  font_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
				  padding: false,
				  h_space: 0,
				  unit_sc: 'dig_s_deg.png',
				  unit_tc: 'dig_s_deg.png',
				  unit_en: 'dig_s_deg.png',
				  negative_image: 'dig_s_minus.png',
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.WEATHER_CURRENT,
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});

				normal_date_img_date_week_img = groupAll.createWidget(hmUI.widget.IMG_WEEK, {
				  x: 171 - 120,
				  y: 340 - 240,
				  week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
				  week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
				  week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});

				normal_date_img_date_day = groupAll.createWidget(hmUI.widget.IMG_DATE, {
				  day_startX: 129 - 120,
				  day_startY: 340 - 240,
				  day_sc_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
				  day_tc_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
				  day_en_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
				  day_zero: 0,
				  day_space: 0,
				  day_align: hmUI.align.CENTER_H,
				  day_is_character: false,
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});	
				
				normal_battery_text_text_img = groupAll.createWidget(hmUI.widget.TEXT_IMG, {
				  x: 216 - 120,
				  y: 253 - 240,
				  font_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
				  padding: false,
				  h_space: 0,
				  align_h: hmUI.align.CENTER_H,
				  type: hmUI.data_type.BATTERY,
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});

				normal_battery_text_separator_img = groupAll.createWidget(hmUI.widget.IMG, {
				  x: 223 - 120,
				  y: 300 - 240,
				  src: 'ico_bat.png',
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});

				normal_system_disconnect_img = groupAll.createWidget(hmUI.widget.IMG_STATUS, {
				  x: 229 - 120,
				  y: 348 - 240,
				  src: 'status_bt.png',
				  type: hmUI.system_status.DISCONNECT,
				  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});				

				console.log('Watch_Face.Buttons');
				Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
				  x: 210,
				  y: 210,
				  w: 60,
				  h: 60,
				  text: '',
				  color: 0xFFFF8C00,
				  text_size: 25,
				  press_src: 'empty.png',
				  normal_src: 'empty.png',
				  click_func: (button_widget) => {
					//hmApp.startApp({url: 'activityAppScreen', native: true });
					switchMinStr(true);
					computeXy(timeSensor);
					
					//toast = weatherData.cityName + ' ' + sunrise.hour+ ':' + sunrise.minute;
			
					//hmUI.showToast({text: toast});
				  }, // end func
				  show_level: hmUI.show_level.ONLY_NORMAL,
				}); // end button	
				
		// function computeAngle(a) {
			// const timeFormat = hmSetting.getTimeFormat();
            // hour = a.hour;
            // minute = a.minute;
			// if (hour > 12) {
				// if (timeFormat == 1) hour = hour - 12
			// }
			// angle1 = hour * 30 + (minute / 2);
			// return angle1;
		// };		

				function text_update() {
					console.log('text_update()');

					hour = timeSensor.hour;
					//minute = timeSensor.minute;
					if (hour > 12) {
						if (timeFormat == 1) hour = hour - 12
					}
					angle1 = hour * 30 + (timeSensor.minute / 2);				  
				  
				  //computeAngle(timeSensor);
				  
				  console.log('update text circle minute_TIME');
				  let valueMinute = timeSensor.minute;
				  let normal_minute_circle_string = parseInt(valueMinute).toString();
				  normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

				  //if (screenType != hmSetting.screen_type.AOD) {
					for (var i = 1; i < 2; i++) {  // hide all symbols
					  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
					};
					let char_Angle = angle1 + minDegrees;
					
					normal_minute_TextCircle[0].setProperty(hmUI.prop.POS_Y, half - (const_dig_min_radius + (const_dig_height / 2)));
					normal_minute_TextCircle[1].setProperty(hmUI.prop.POS_Y, half - (const_dig_min_radius + (const_dig_height / 2)));	
					if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {
						char_Angle = angle1 - minDegrees + 180;
						normal_minute_TextCircle[0].setProperty(hmUI.prop.POS_Y, half + (const_dig_min_radius - (const_dig_height / 2)));
						normal_minute_TextCircle[1].setProperty(hmUI.prop.POS_Y, half + (const_dig_min_radius - (const_dig_height / 2)));
					};					
					
					if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
					  let normal_minute_TextCircle_img_angle = 0;
					  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, const_dig_min_radius));	
					  
					  // alignment = CENTER_H
					  let normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_img_angle * (normal_minute_circle_string.length - 1);
					  if (!(angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate)) {
						  normal_minute_TextCircle_angleOffset = -normal_minute_TextCircle_angleOffset;
						  char_Angle += normal_minute_TextCircle_angleOffset - otstup;
					  } else {
						  char_Angle += normal_minute_TextCircle_angleOffset + otstup;
					  };
					  // alignment end	
					  
					  let firstSymbol = true;
					  let index = 0;
					  for (let char of normal_minute_circle_string) {
						let charCode = char.charCodeAt()-48;
						if (index >= 2) break;
						if (charCode >= 0 && charCode < 10) { 
						  if (!firstSymbol) {
							  if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {
								char_Angle -= normal_minute_TextCircle_img_angle;
							  } else {
								  char_Angle += normal_minute_TextCircle_img_angle;
							  };
						  };
						  firstSymbol = false;
						  normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
						  normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, half - normal_minute_TextCircle_img_width / 2);
						  normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
						  normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
						
						  if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {
							  char_Angle -= normal_minute_TextCircle_img_angle + otstup;
						  } else {
							  char_Angle += normal_minute_TextCircle_img_angle + otstup;
						  };						  
						  index++;
						};  // end if digit
					  };  // end char of string
					}  // end isFinite

				  //};
							
				offsetX = half + const_group_radius * Math.sin((angle1 + 180) * (Math.PI / 180)) - const_group_radius;
				offsetY = half - const_group_radius * Math.cos((angle1 + 180) * (Math.PI / 180)) - const_group_radius;
				
				groupAll.setProperty(hmUI.prop.MORE, { x: offsetX, y: offsetY });		
				  		  			
				  
				}
				
				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
				  resume_call: (function () {
					console.log('resume_call()');
					switchMinStr(false);
					computeXy(timeSensor);
					setSunIcons(timeSensor);
					text_update();
					checkConnection();
					stopVibro();					
/*					if (screenType == hmSetting.screen_type.WATCHFACE) {
					    if (!normal_timerTextUpdate) {
							normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
							  computeXy(timeSensor);
							  text_update();
							}));  // end timer 
					    };  // end timer check
					};  // end screenType

 					if (screenType == hmSetting.screen_type.AOD) {
					  if (!idle_timerTextUpdate) {
						  idle_timerTextUpdate = timer.createTimer(0, 60000, (function (option) {
						  computeXy(timeSensor);
						  text_update();
						}));  // end timer 
					  };  // end timer check
					};  // end screenType */

				  }),
				  pause_call: (function () {
					console.log('pause_call()');
					if (normal_timerTextUpdate) {
					  timer.stopTimer(normal_timerTextUpdate);
					  normal_timerTextUpdate = undefined;
					}
					if (idle_timerTextUpdate) {
					  timer.stopTimer(idle_timerTextUpdate);
					  idle_timerTextUpdate = undefined;
					};

				  }),
				});

            },
            onInit() {
                logger.log("index page.js on init invoke");
				loadSettings();
            },
            build() {
                this.init_view();
                logger.log("index page.js on ready invoke");
            },
            onDestroy() {
                //timer.stopTimer(timeSensor);
				//timer.stopTimer(normal_timerTextUpdate);
                logger.log("index page.js on destroy invoke");
            },
        });
    })();
} catch (e) {
    console.log("Mini Program Error", e);
    e && e.stack && e.stack.split(/\n/).forEach((i) => console.log("error stack", i));
}
