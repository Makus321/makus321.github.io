﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
		//const hmInteraction = __$$R$$__('@zos/interaction');
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('Sakura');
        //end of ignored block

        let val, hour, minute, groupX, groupY, newmin, hideAOD, hour_pointer_img, str_lenght, min_radius, minStr, minMaskNum, secBackNum, hourMaskNum, minMaskDigNum, offsetX, offsetY, offsetX1, offsetY1;

		const minDegrees = 0;
		//const hourDegress = -1;
		//const secDegres = 0;
		const otstup = -1;
		const half = 240;
		const const_group_radius = 130;
		const const_hour_height = 76;
		const const_minute_height = 60;
		const normal_hour_img_width = 37;
		const normal_minute_img_width = 29;
		const const_angle_start_rotate = 91;
		const const_angle_stop_rotate = 270;
		const const_dig_hour_radius = 180;
		const const_dig_min_radius = 190;
		const const_hour_pointer_width = 24;
		const const_hour_pointer_y = 120;
		const timeFormat = hmSetting.getTimeFormat();
		const const_hour_group_x = 240;
		const const_hour_group_y = 15;
		const const_left_group_x = 32;
	    const const_left_group_y = 161;
		const const_right_group_x = 270;
		const const_right_group_y = 150;
		const const_right_group_d = 180;
		const const_right_group_radius = const_right_group_x + const_right_group_d / 2 - half;
		const crownSensitivity = 50		// уровень чувствительности колесика

        //dynamic modify start
		let bgColor = [0xffffff, 0x0026FF, 0xFFD800, 0xFF0000, 0xe1ff1b, 0x86ff1b, 0x1bfcff, 0x1b91ff, 0x7c1bff, 0xec1bff, 0xFFCCFD]
        let Button_1 = '';
		let degreeSum = 0;
		let buttonAOD = '';
        let normal_back = '';
		let aod_back = '';
		let group_left = '';
		let group_right = '';
        let normal_timerUpdateSec = undefined;
        let normal_timerTimeUpdate = undefined;
        let idle_timerUpdateSecSmooth = undefined;
        let timeSensor = '';
		let normal_hour_TextRotate = new Array(2);
		let group_hour_mask = new Array(2);
		let group_minute_mask = new Array(2);
		let hour_pointer_img_ASCIIARRAY = new Array(13);
		let hour_pointer_mask_img_ASCIIARRAY = new Array(6);
		let hour_pointer_img_mask = '';
		let hour_dig_mask_img_ASCIIARRAY = new Array(10);
		let minute_dig_mask_img_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
		let screenType = undefined;
		var angle1 = 0;		

		// vibrate function

		const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
		let timer_StopVibrate = null;

		function loadSettings() {			
			if (hmFS.SysProGetInt('minstr_longline') === undefined) {
				minStr = 0;
				hmFS.SysProSetInt('minstr_longline', minStr);
			} else {
				minStr = hmFS.SysProGetInt('minstr_longline');
			};
			if (hmFS.SysProGetInt('aod_longline') === undefined) {
				hideAOD = 0;
				hmFS.SysProSetInt('aod_longline', hideAOD);
			} else {
				hideAOD = hmFS.SysProGetInt('aod_longline');
			};
			secBackNum = minStr % 11;
		};	

		function fillColor() {
			secBackNum = minStr % 11;
			normal_back.setProperty(hmUI.prop.MORE, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				radius: 240,
				color: bgColor[secBackNum] 
			});
		}

		function switchSkin(increment = true) {							 
			if (increment) {
				minStr++;
				if (minStr > 999) minStr = 0;
			} else {
				minStr--;
				if (minStr < 0) minStr = 999;
			};
			hmFS.SysProSetInt('minstr_longline', minStr);
			vibro();
			//hmUI.showToast({text: parseInt(minStr).toString()});
		};	

		function switchAOD() {
			hideAOD++;
			hideAOD = hideAOD % 2;
			hmFS.SysProSetInt('aod_longline', hideAOD);
			if (hideAOD === 0) {
				hmUI.showToast({text: 'AOD минимум'});
			} else {
				hmUI.showToast({text: 'AOD полный'});
			}
			vibro();
		}
		
		function vibro(scene = 28) {
		  let stopDelay = 200;
		  stopVibro();
		  vibrate.stop();
		  vibrate.scene = scene;
		  if(scene < 23 || scene > 25) stopDelay = 1220;
		  vibrate.start();
		  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibro, {});
		}

		function stopVibro(){
		  vibrate.stop();
		  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
		}

		// end vibrate function
		
		// repeat alerts
		function repeat_alerts() {
		  let hourEnd = false;
		  if(timeSensor.minute == 0) {
			hourEnd = true;
			vibro(5);
		  }
		};
		
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
			
			// vibration when connecting or disconnecting

			function checkConnection() {
			  console.log('checkConnection()');
			  hmBle.removeListener;
			  hmBle.addListener(function (status) {
				if(!status) {
				  hmUI.showToast({text: "Связь потеряна"});
				  vibro(9);
				}
				if(status) {
				  hmUI.showToast({text: "Связь восстановлена"});
				  vibro(0);
				}
			  });
			};

			aod_back = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  src: 'back.png',
			  show_level: hmUI.show_level.ONLY_AOD,
			});
			
			normal_back = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: 0,
			  y: 0,
			  w: 480,
			  h: 480,
			  radius: 240,
			  color: bgColor[secBackNum],
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
				repeat_alerts();
				//switchSkin(false);
				text_update();
			});						

			sec_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
			  second_centerX: 240,
			  second_centerY: 240,
			  second_posX: 240,
			  second_posY: 240,
			  second_path: 'sec.png',
			  fresh_frequency: 20,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			group_left = hmUI.createWidget(hmUI.widget.GROUP, {
			  x: const_left_group_x,
			  y: const_left_group_y,
			  w: 240,
			  h: 240,
			});	

			normal_clover_pic = group_left.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  src: 'group_left_1.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
				
			idle_clover_pic = group_left.createWidget(hmUI.widget.IMG, {
			  x: 0,
			  y: 0,
			  src: 'group_left_2.png',
			  show_level: hmUI.show_level.ONLY_AOD,
			});
				
			normal_weather_image_progress_img_level = group_left.createWidget(hmUI.widget.IMG_LEVEL, {
			  x: 123 - const_left_group_x, // 123 старое // 45
			  y: 238 - const_left_group_y, 
			  image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
			  image_length: 29,
			  type: hmUI.data_type.WEATHER_CURRENT,
			  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
			});

			normal_temperature_current_text_img = group_left.createWidget(hmUI.widget.TEXT_IMG, {
			  x: 43 - const_left_group_x, // 43 старое // 116
			  y: 244 - const_left_group_y, 
			  font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
			  padding: false,
			  h_space: 0,
			  unit_sc: 'dig_s_deg.png',
			  unit_tc: 'dig_s_deg.png',
			  unit_en: 'dig_s_deg.png',
			  negative_image: 'dig_s_minus.png',
			  align_h: hmUI.align.CENTER_H,
			  type: hmUI.data_type.WEATHER_CURRENT,
			  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
			});
				
			normal_battery_text_text_img = group_left.createWidget(hmUI.widget.TEXT_IMG, {
			  x: 88 - const_left_group_x,
			  y: 176 - const_left_group_y,
			  font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
			  padding: false,
			  h_space: 0,
			  align_h: hmUI.align.CENTER_H,
			  type: hmUI.data_type.BATTERY,
			  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
			});

			normal_battery_text_separator_img = group_left.createWidget(hmUI.widget.IMG, {
			  x: 94 - const_left_group_x,
			  y: 212 - const_left_group_y,
			  src: 'ico_bat.png',
			  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
			});			

			group_right = hmUI.createWidget(hmUI.widget.GROUP, {
			  x: const_right_group_x,
			  y: const_right_group_y,
			  w: 240,
			  h: 240,
			});			
			
            normal_date_img_date_week_img = group_right.createWidget(hmUI.widget.IMG_WEEK, {
              x: 310 - const_right_group_x,
              y: 150 - const_right_group_y,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });		

			right_pic_normal = group_right.createWidget(hmUI.widget.IMG, {
			  x: 365 - const_right_group_x,
			  y: 194 - const_right_group_y,
			  src: 'group_right_1.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	

			right_pic_aod = group_right.createWidget(hmUI.widget.IMG, {
			  x: 365 - const_right_group_x,
			  y: 194 - const_right_group_y,
			  src: 'group_right_2.png',
			  show_level: hmUI.show_level.ONLY_AOD,
			});	

            normal_date_img_date_day = group_right.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 382 - const_right_group_x,
              day_startY: 216 - const_right_group_y,
              day_sc_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
              day_tc_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
              day_en_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],		  
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });		

			normal_system_disconnect_img = group_right.createWidget(hmUI.widget.IMG_STATUS, {
			  x: 400 - const_right_group_x,
			  y: 167 - const_right_group_y,
			  src: 'status_bt.png',
			  type: hmUI.system_status.DISCONNECT,
			  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
			});				

            hour_pointer_img_mask = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: half - const_hour_pointer_width / 2,
              pos_y: const_hour_pointer_y,
              center_x: half,
              center_y: half,
              src: 'hour_str_mask_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });	
           
            hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: half - const_hour_pointer_width / 2,
              pos_y: const_hour_pointer_y,
              center_x: half,
              center_y: half,
              src: 'hour_str_11.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });		  

            hour_pointer_img_ASCIIARRAY[0] = 'hour_str_00.png';  
            hour_pointer_img_ASCIIARRAY[1] = 'hour_str_0.png';  
            hour_pointer_img_ASCIIARRAY[2] = 'hour_str_1.png';  
            hour_pointer_img_ASCIIARRAY[3] = 'hour_str_2.png';  
            hour_pointer_img_ASCIIARRAY[4] = 'hour_str_3.png';  
            hour_pointer_img_ASCIIARRAY[5] = 'hour_str_4.png';  
            hour_pointer_img_ASCIIARRAY[6] = 'hour_str_5.png';  
            hour_pointer_img_ASCIIARRAY[7] = 'hour_str_6.png';  
            hour_pointer_img_ASCIIARRAY[8] = 'hour_str_7.png';  
            hour_pointer_img_ASCIIARRAY[9] = 'hour_str_8.png';  
			hour_pointer_img_ASCIIARRAY[10] = 'hour_str_9.png';  
			hour_pointer_img_ASCIIARRAY[11] = 'hour_str_10.png'; 
			hour_pointer_img_ASCIIARRAY[12] = 'hour_str_11.png'; 
			
			hour_pointer_mask_img_ASCIIARRAY[0] = 'hour_str_mask_0.png';  
            hour_pointer_mask_img_ASCIIARRAY[1] = 'hour_str_mask_1.png';  
            hour_pointer_mask_img_ASCIIARRAY[2] = 'hour_str_mask_2.png';  
            hour_pointer_mask_img_ASCIIARRAY[3] = 'hour_str_mask_3.png';  
            hour_pointer_mask_img_ASCIIARRAY[4] = 'hour_str_mask_4.png';  
            hour_pointer_mask_img_ASCIIARRAY[5] = 'hour_str_mask_5.png';  	
			
			hour_dig_mask_img_ASCIIARRAY[0] = 'dig_h_2_mask_0.png';  
            hour_dig_mask_img_ASCIIARRAY[1] = 'dig_h_2_mask_1.png';  
            hour_dig_mask_img_ASCIIARRAY[2] = 'dig_h_2_mask_2.png';  
            hour_dig_mask_img_ASCIIARRAY[3] = 'dig_h_2_mask_3.png';  
			
			minute_dig_mask_img_ASCIIARRAY[0] = 'dig_m_2_mask_0.png';  
            minute_dig_mask_img_ASCIIARRAY[1] = 'dig_m_2_mask_1.png';  
            minute_dig_mask_img_ASCIIARRAY[2] = 'dig_m_2_mask_2.png';  
            minute_dig_mask_img_ASCIIARRAY[3] = 'dig_m_2_mask_3.png';  
			minute_dig_mask_img_ASCIIARRAY[3] = 'dig_m_2_mask_4.png';  

            normal_hour_TextRotate_ASCIIARRAY[0] = 'dig_h_2_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'dig_h_2_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'dig_h_2_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'dig_h_2_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'dig_h_2_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'dig_h_2_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'dig_h_2_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'dig_h_2_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'dig_h_2_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'dig_h_2_9.png';  // set of images with numbers
			
			//let group_hour_mask = new Array(2);
			for (let i = 0; i < 2; i++) {
				group_hour_mask[i] = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: half,
					center_y: half,
					pos_x: const_hour_group_x,
					pos_y: const_hour_group_y,					
					angle: 0,					
					src: 'dig_h_2_mask_1.png',
					show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});
				group_hour_mask[i].setProperty(hmUI.prop.VISIBLE, false);
			};
			
			for (let i = 0; i < 2; i++) {
				group_minute_mask[i] = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: half,
					center_y: half,
					pos_x: const_hour_group_x,
					pos_y: const_hour_group_y,					
					angle: 0,					
					src: 'dig_m_2_mask_1.png',
					show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
				});
				group_minute_mask[i].setProperty(hmUI.prop.VISIBLE, false);
			};			
			
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: half,
                center_y: half,
                pos_x: const_hour_group_x,
                pos_y: const_hour_group_y,
                angle: 0,
                src: 'dig_m_2_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_minute_TextRotate_ASCIIARRAY[0] = 'dig_m_2_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'dig_m_2_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'dig_m_2_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'dig_m_2_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'dig_m_2_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'dig_m_2_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'dig_m_2_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'dig_m_2_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'dig_m_2_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'dig_m_2_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: half,
                center_y: half,
                pos_x: 240,
                pos_y: 390,
                angle: 0,
                src: 'dig_m_1_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
			
			// Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			//   x: 210,
			//   y: 210,
			//   w: 60,
			//   h: 60,
			//   text: '',
			//   color: 0xFFFF8C00,
			//   text_size: 25,
			//   press_src: 'empty.png',
			//   normal_src: 'empty.png',
			//   click_func: (button_widget) => {
			// 	switchSkin(true);
			// 	fillColor();
			// 	text_update();
			// 	//let toast = offsetX.toString() + ',' + offsetY.toString()
			// 	//hmUI.showToast({text: toast});
			//   }, // end func
			//   show_level: hmUI.show_level.ONLY_NORMAL,
			// }); // end button		
			
			buttonAOD = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 210,
				y: 210, // 420 для низа
				w: 60,
				h: 60,
				text: '',
				color: 0xFFFF8C00,
				text_size: 25,
				press_src: 'empty.png',
				normal_src: 'empty.png',
				click_func: (button_widget) => {
					switchAOD();
				}, // end func
				show_level: hmUI.show_level.ONLY_NORMAL,
			  }); // end button	


            function text_update() {
				minStr = hmFS.SysProGetInt('minstr_longline');
				console.log('text_update()');			
				let valueHour =  timeSensor.format_hour;
				//let valueHour =  15;
				let valueMinute =  timeSensor.minute;
				hour = valueHour;
 				if (hour > 12) {hour = hour - 12};
				angle1 = hour * 30 + (valueMinute / 2);				   // для часов
				//angle1 = 210;
				//angle1 = valueMinute * 6;								// для минут
				
				//screenType = hmSetting.getScreenType();
				//hideAOD = minStr % 2;
				if (hideAOD === 0 && (screenType == hmSetting.screen_type.AOD)) {
					group_left.setProperty(hmUI.prop.VISIBLE, false);
					group_right.setProperty(hmUI.prop.VISIBLE, false);
				} else {
					group_left.setProperty(hmUI.prop.VISIBLE, true);
					group_right.setProperty(hmUI.prop.VISIBLE, true);
				}

				minMaskNum = minStr % 6;
				hour_pointer_img.setProperty(hmUI.prop.ANGLE, angle1);
				hour_pointer_img_mask.setProperty(hmUI.prop.ANGLE, angle1);
				
				hourMaskNum = minStr % 4;
				group_hour_mask[0].setProperty(hmUI.prop.SRC, hour_dig_mask_img_ASCIIARRAY[hourMaskNum]);
				group_hour_mask[1].setProperty(hmUI.prop.SRC, hour_dig_mask_img_ASCIIARRAY[hourMaskNum]);
				
				minMaskDigNum = minStr % 5;
				group_minute_mask[0].setProperty(hmUI.prop.SRC, minute_dig_mask_img_ASCIIARRAY[minMaskDigNum]);
				group_minute_mask[1].setProperty(hmUI.prop.SRC, minute_dig_mask_img_ASCIIARRAY[minMaskDigNum]);
				
				str_lenght = Math.round(valueMinute / 5); //trunc
				hour_pointer_img.setProperty(hmUI.prop.SRC, hour_pointer_img_ASCIIARRAY[str_lenght]);
				hour_pointer_img_mask.setProperty(hmUI.prop.SRC, hour_pointer_mask_img_ASCIIARRAY[minMaskNum]);
				min_radius = 20 * (str_lenght) - (const_minute_height / 2);
						
				offsetX = const_left_group_x + const_group_radius + const_group_radius * Math.sin((angle1 - 90) * (Math.PI / 180)) - 0;
				offsetY = const_left_group_y - const_group_radius * Math.cos((angle1 - 90) * (Math.PI / 180)) - 0;				
				group_left.setProperty(hmUI.prop.MORE, { x: offsetX, y: offsetY });
				
				offsetX1 = half + const_right_group_radius  * Math.sin((angle1 + 90) * (Math.PI / 180)) - const_right_group_d / 2;
				offsetY1 = half - const_right_group_radius  * Math.cos((angle1 + 90) * (Math.PI / 180)) - const_right_group_d / 2;				
				group_right.setProperty(hmUI.prop.MORE, { x: offsetX1, y: offsetY1 });				
							
				let normal_hour_circle_string = parseInt(valueHour).toString();
				//normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0'); // добавляем ведущий ноль

				let char_Angle = angle1 + minDegrees;
				for (var i = 0; i < 2; i++) {  // hide all symbols
				  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
				  group_hour_mask[i].setProperty(hmUI.prop.VISIBLE, false);
				  normal_hour_TextRotate[i].setProperty(hmUI.prop.POS_Y, half - (const_dig_hour_radius + (const_hour_height / 2)));
				  group_hour_mask[i].setProperty(hmUI.prop.POS_Y, half - (const_dig_hour_radius + (const_hour_height / 2)));
				  if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {
					  normal_hour_TextRotate[i].setProperty(hmUI.prop.POS_Y, half + (const_dig_hour_radius - (const_hour_height / 2)));
					  group_hour_mask[i].setProperty(hmUI.prop.POS_Y, half + (const_dig_hour_radius - (const_hour_height / 2)));
				  };
				};
				if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {char_Angle = angle1 - minDegrees + 180	};									
				if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it			  
				  let index = 0;
				  let pos_x_offset = half - normal_hour_img_width;
				  if (normal_hour_circle_string.length === 1) pos_x_offset = half - normal_hour_img_width /2;
				  for (let char of normal_hour_circle_string) {
					let charCode = char.charCodeAt()-48;
					if (index >= 2) break;
					if (charCode >= 0 && charCode < 10) { 						
					  if (index === 1) pos_x_offset += normal_hour_img_width + otstup;
					  normal_hour_TextRotate[index].setProperty(hmUI.prop.ANGLE, char_Angle);
					  group_hour_mask[index].setProperty(hmUI.prop.ANGLE, char_Angle);
					  normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, pos_x_offset);
					  group_hour_mask[index].setProperty(hmUI.prop.POS_X, pos_x_offset);
					  normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
					  group_hour_mask[index].setProperty(hmUI.prop.VISIBLE, true);
					  normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);					  
					  index++;
					};  // end if digit
				  };  // end char of string 
				};  // end isFinite 

				let normal_minute_circle_string = parseInt(valueMinute).toString();
				normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0'); // добавляем ведущий ноль

				angle1 += 180;
				angle1 = angle1 % 360;
				char_Angle = angle1 + minDegrees ;
				for (var i = 0; i < 2; i++) {  // hide all symbols
				  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
				  group_minute_mask[i].setProperty(hmUI.prop.VISIBLE, false);
				  // half - (const_dig_min_radius + (const_hour_height / 2) // постоянная длина стрелки
				  // half - (min_radius + (const_minute_height / 2)) // переменная длина стрелки
				  normal_minute_TextRotate[i].setProperty(hmUI.prop.POS_Y, half - (const_dig_min_radius + (const_minute_height / 2)));
				  group_minute_mask[i].setProperty(hmUI.prop.POS_Y, half - (const_dig_min_radius + (const_minute_height / 2)));

				  if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {
					  normal_minute_TextRotate[i].setProperty(hmUI.prop.POS_Y, half + (const_dig_min_radius - (const_minute_height / 2)));
					  group_minute_mask[i].setProperty(hmUI.prop.POS_Y, half + (const_dig_min_radius - (const_minute_height / 2)));
				  };
				};
				if (angle1 >= const_angle_start_rotate && angle1 < const_angle_stop_rotate) {char_Angle = angle1 - minDegrees + 180	};									
				if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it			  
				  let index = 0;
				  let pos_x_offset = half - normal_minute_img_width;
				  for (let char of normal_minute_circle_string) {
					let charCode = char.charCodeAt()-48;
					if (index >= 2) break;
					if (charCode >= 0 && charCode < 10) { 						
					  if (index === 1) pos_x_offset += normal_minute_img_width + otstup;
					  normal_minute_TextRotate[index].setProperty(hmUI.prop.ANGLE, char_Angle);
					  group_minute_mask[index].setProperty(hmUI.prop.ANGLE, char_Angle);
					  normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, pos_x_offset);
					  group_minute_mask[index].setProperty(hmUI.prop.POS_X, pos_x_offset);
					  normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
					  group_minute_mask[index].setProperty(hmUI.prop.VISIBLE, true);
					  normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);					  
					  index++;
					};  // end if digit
				  };  // end char of string 
				};  // end isFinite 				
            };

			function onDigitalCrown() {
				hmApp.registerSpinEvent(function (key, degree) {
						//hmUI.showToast({ text: `degree = ${degree}` })
						if (key === hmApp.key.HOME) {
							degreeSum += degree;
							if (Math.abs(degreeSum) > crownSensitivity){
								if (degreeSum > 0) {
									switchSkin(true);
								} else {
									switchSkin(false);
								};
								fillColor();
								text_update();
								degreeSum = 0;
							}
						}
					}
				) // crown
			};

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
				checkConnection();
				stopVibro();				
				setTimeout(() => {
					onDigitalCrown();
				}, 350);
              }),
              pause_call: (function () {
				hmApp.unregisterSpinEvent();
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
				loadSettings();
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
				hmApp.unregisterSpinEvent();
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}