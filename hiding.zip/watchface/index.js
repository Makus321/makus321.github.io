﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

		var minStr;
		let StrLabel = ["min_str0.png", "min_str1.png", "min_str2.png"];
        let editBg = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_hour_cover_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_hour_cover_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let idle_system_disconnect_img = ''
        let Button_1 = ''
        let stopVibro_Timer = null;	
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);	
		let timer_StopVibrate = null;
		let timeSensor = ''		

		function loadSettings() {			
			if (hmFS.SysProGetInt('minstr_aod') === undefined) {
				minStr = 0;
				hmFS.SysProSetInt('minstr_aod', minStr);
			} else {
				minStr = hmFS.SysProGetInt('minstr_aod');
			}
		}

		
	

        //dynamic modify end
	

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
			
			const deviceInfo = hmSetting.getDeviceInfo();
			if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
			timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
			  repeat_alerts();
			  let updateHour = timeSensor.minute == 0;
			  time_update(updateHour, true);
			});	
			
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'back.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'back1.png' },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 107,
              hour_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              hour_zero: 0,
              hour_space: -80,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 0,
              pos_y: 240 - 0,
              center_x: 240,
              center_y: 240,
              src: 'hour_str.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -10,
              y: -10,
              src: 'h15.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();

            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 11,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'min_str0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'm15.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD ,
            });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }


            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 377,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 382,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_s_deg.png',
              unit_tc: 'dig_s_deg.png',
              unit_en: 'dig_s_deg.png',
              negative_image: 'dig_s_minus.png',
              invalid_image: 'dig_s_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 60,
              day_sc_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              day_tc_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              day_en_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 246,
              y: 60,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 226,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

			 // vibrate function
			function vibro(scene = 28) {
			  let stopDelay = 200;
			  stopVibro();
			  vibrate.stop();
			  vibrate.scene = scene;
			  if(scene < 23 || scene > 25) stopDelay = 1220;
			  vibrate.start();
			  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibro, {});
			};

			function stopVibro(){
			  vibrate.stop();
			  if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
			};
			// end vibrate function
			
			// repeat alerts
			function repeat_alerts() {
			  let hourEnd = false;
			  if(timeSensor.minute == 0) {
				hourEnd = true;
				vibro(5);
			  };
			};
			// end repeat alerts

			// vibration when connecting or disconnecting
			function checkConnection() {
			  console.log('checkConnection()');
			  hmBle.removeListener;
			  hmBle.addListener(function (status) {
				if(!status) {
				  hmUI.showToast({text: "Связь потеряна"});
				  vibro(9);
				}
				if(status) {
				  hmUI.showToast({text: "Связь восстановлена"});
				  vibro(0);
				};
			  });
			};
			// end vibration when connecting or disconnecting	


			function switchMinStr(increment = true) {						
				if (increment) {
					minStr = (minStr + 1) % 3;
					hmFS.SysProSetInt('minstr_aod', minStr);
					vibro();
				};				
				normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, StrLabel[minStr]);
				//hmUI.showToast({text: StrLabel[minStr]});
			}			
		
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
			  
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;

			  hLabel = 'h' + minute + '.png';
              mLabel = 'm' + minute + '.png';
			  normal_analog_clock_pro_minute_cover_pointer_img.setProperty(hmUI.prop.SRC, `${mLabel}`);
			  normal_analog_clock_pro_hour_cover_pointer_img.setProperty(hmUI.prop.SRC, `${hLabel}`);

              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };			
		
            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'hour_str.png',
              normal_src: 'hour_str.png',
              click_func: (button_widget) => {
                //hmApp.startApp({url: 'activityAppScreen', native: true });
				switchMinStr(true);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block


            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');		
				switchMinStr(false);
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(true, true);
					  checkConnection();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
				loadSettings();
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
				timer.stopTimer(normal_timerUpdateSec);
				timer.stopTimer(normal_timerUpdateSecSmooth);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}