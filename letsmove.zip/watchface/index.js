﻿
  try {
    (() => {
        
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const logger = Logger.getLogger('Mak321');
        let dotColor = 0;
        let dotColorDay = dotColor;
        let dotColorNight = dotColor;
        let vibroOptions = 0;

        function loadSettings() {			
          if (hmFS.SysProGetInt('dotcolor_letsmove') === undefined) {
            dotColorDay = 0;
            hmFS.SysProSetInt('dotcolor_letsmove', dotColorDay);
          } else {
            dotColorDay = hmFS.SysProGetInt('dotcolor_letsmove');
          };
          if (hmFS.SysProGetInt('dotcolorn_letsmove') === undefined) {
            dotColorNight = 0;
            hmFS.SysProSetInt('dotcolorn_letsmove', dotColorNight);
          } else {
            dotColorNight = hmFS.SysProGetInt('dotcolorn_letsmove');
          };
          if (hmFS.SysProGetInt('vibro_letsmove') === undefined) {
            vibroOptions = 0;
            hmFS.SysProSetInt('vibro_letsmove', vibroOptions);
          } else {
            vibroOptions = hmFS.SysProGetInt('vibro_letsmove');
          };
        };

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
           init_view() {        
              let timer1 = undefined;
              let timer0 = undefined;
              let timeSensor = '';
              let weatherSensor;
              let sunriseIMG = '';
              let sunsetIMG = '';
              let degreeSum = 0;
              let Num1 = new Array(19);
              let Num2 = new Array(19);
              let Num3 = new Array(19);
              let Num4 = new Array(19);
              let Num5 = new Array(19);
              let Num6 = new Array(19);
              let delim = new Array(19);
              let timeNums = [Num1, Num2, Num3, Num4, Num5, Num6, delim];
              let Num1vector = [{x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}];
              let Num2vector = Num1vector;
              let Num3vector = Num1vector;
              let Num4vector = Num1vector;
              let Num5vector = Num1vector;
              let Num6vector = Num1vector;
              let Delimvector = Num1vector;
              let numsVector = [Num1vector, Num2vector, Num3vector, Num4vector, Num5vector, Num6vector, Delimvector];
              let frame = 0;
              const sunDelta = 2;
              const maxFrame = 7;
              const frameRate = 50;
              const maxColor = 18;
              const screenSimbols = 7;
              const dotColor_ASCIIARRAY = ['dot.png', 'dot0sec.png', 'dot1.png', 'dot1sec.png', 'dot2.png', 'dot2sec.png', 'dot3.png', 'dot3sec.png', 'dot4.png', 'dot4sec.png',
                'dot5.png', 'dot5sec.png', 'dot6.png', 'dot6sec.png', 'dot7.png', 'dot7sec.png', 'dot8.png', 'dot8sec.png', 'dot9.png', 'dot9sec.png', 'dot10.png', 'dot10sec.png', 'dot11.png', 'dot11sec.png',
                'dot12.png', 'dot12sec.png', 'dot13.png', 'dot13sec.png', 'dot14.png', 'dot14sec.png', 'dot15.png', 'dot15sec.png', 'dot16.png', 'dot16sec.png', 'dot17.png', 'dot17sec.png'];
              let multX = 18;
              let multY = 22;
              let multXsec = 11;
              let multYsec = 14;
              let X1 = 15;
              let X2 = X1 + multX * 5 + 10;
              let X3 = X2 + multX * 5 + 65;
              let X4 = X3 + multX * 5 + 10;
              let X5 = 180;
              let X6 = X5 + multXsec * 5 + 7;
              let X7 = X2 + multX * 5 - 5;
              let normal_background_bg = '';
              let normal_background_bg_img = '';
              let normal_battery_text_text_img = ''
              let normal_battery_text_separator_img = ''
              let normal_weather_image_progress_img_level = ''
              let normal_temperature_current_text_img = ''
              let normal_date_img_date_week_img = ''
              let normal_date_img_date_day = ''
              let normal_system_disconnect_img = ''
              let normal_battery_linear_scale = ''
              let bat_scale = '';
              let Button_1 = '';
              let numToDraw = new Array(19);
              const y1 = 360;
              const y0 = 170; 
              const half = 480 / 2;
              const crownSensitivity = 50;
              const zeroArray = [{x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 0, y: 2}, {x: 3, y: 2}, {x: 4, y: 2}, {x: 0, y: 3}, {x: 2, y: 3}, {x: 4, y: 3}, {x: 0, y: 4}, {x: 1, y: 4}, {x: 4, y: 4}, {x: 0, y: 5}, {x: 4, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y:6}];
              const oneArray = [{x: 1, y: 1}, {x: 2, y: 0}, {x: 2, y: 1}, {x: 2, y: 0}, {x: 2, y: 1}, {x: 2, y: 2}, {x: 2, y: 2}, {x: 2, y: 2}, {x: 2, y: 3}, {x: 2, y: 5}, {x: 2, y: 6}, {x: 2, y: 4}, {x: 2, y: 5}, {x: 2, y: 4}, {x: 0, y: 6}, {x: 4, y: 6}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y:6}];
              const twoArray = [{x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 2}, {x: 4, y: 2}, {x: 2, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 1, y: 4}, {x: 0, y: 5}, {x: 4, y: 5}, {x: 0, y: 6}, {x: 4, y: 6}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y:6}];
              const threeArray = [{x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 2}, {x: 4, y: 2}, {x: 2, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 4, y: 4}, {x: 0, y: 5}, {x: 4, y: 5}, {x: 1, y: 6}, {x: 3, y: 6}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y:6}];              
              const fourArray = [{x: 2, y: 1}, {x: 3, y: 0}, {x: 4, y: 0}, {x: 1, y: 2}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 3}, {x: 4, y: 4}, {x: 0, y: 3}, {x: 1, y: 4}, {x: 2, y: 4}, {x: 3, y: 4}, {x: 0, y: 4}, {x: 4, y: 6}, {x: 4, y: 6}, {x: 4, y: 5}, {x: 4, y: 6}, {x: 4, y: 6}, {x: 4, y:6}];              
              const fiveArray = [{x: 0, y: 0}, {x: 1, y: 0}, {x: 2, y: 0}, {x: 0, y: 1}, {x: 3, y: 0}, {x: 4, y: 0}, {x: 4, y: 3}, {x: 4, y: 4}, {x: 0, y: 2}, {x: 1, y: 2}, {x: 2, y: 2}, {x: 3, y: 2}, {x: 0, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 4, y: 5}, {x: 3, y: 6}, {x: 3, y: 6}, {x: 3, y:6}];               
              const sixArray = [{x: 0, y: 2}, {x: 1, y: 1}, {x: 2, y: 0}, {x: 0, y: 3}, {x: 3, y: 0}, {x: 3, y: 0}, {x: 3, y: 3}, {x: 4, y: 4}, {x: 0, y: 4}, {x: 1, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 0, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 4, y: 5}, {x: 3, y: 6}, {x: 3, y: 6}, {x: 3, y:6}]; 
              const sevenArray = [{x: 0, y: 0}, {x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 4, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 4, y: 2}, {x: 4, y: 2}, {x: 3, y: 3}, {x: 3, y: 3}, {x: 3, y: 4}, {x: 3, y: 4}, {x: 3, y: 5}, {x: 3, y: 5}, {x: 3, y: 6}, {x: 3, y: 6}, {x: 3, y: 6}, {x: 3, y:6}];
              const eightArray = [{x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 0, y: 2}, {x: 3, y: 3}, {x: 4, y: 2}, {x: 1, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 0, y: 4}, {x: 1, y: 3}, {x: 4, y: 4}, {x: 0, y: 5}, {x: 4, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 3, y:6}];
              const nineArray = [{x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 0, y: 1}, {x: 4, y: 1}, {x: 0, y: 2}, {x: 4, y: 3}, {x: 4, y: 2}, {x: 1, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 1, y: 3}, {x: 1, y: 3}, {x: 4, y: 4}, {x: 3, y: 5}, {x: 3, y: 5}, {x: 1, y: 6}, {x: 2, y: 6}, {x: 2, y:6}];
              const delimArray = [{x: 2, y: 1}, {x: 3, y: 1}, {x: 2, y: 2}, {x: 3, y: 2}, {x: 2, y: 1}, {x: 3, y: 1}, {x: 2, y: 2}, {x: 3, y: 2}, {x: 2, y: 5}, {x: 3, y: 5}, {x: 2, y: 6}, {x: 3, y: 6}, {x: 2, y: 5}, {x: 3, y: 5}, {x: 2, y: 6}, {x: 3, y: 6}, {x: 2, y: 1}, {x: 2, y: 5}, {x: 3, y:6}];      
              const middleArray = [{x: 0, y: 3}, {x: 1, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 4, y: 3}, {x: 4, y: 3}, {x: 3, y: 3}, {x: 2, y: 3}, {x: 1, y: 3}, {x: 0, y: 3}, {x: 0, y: 3}, {x: 1, y: 3}, {x: 2, y: 3}, {x: 3, y: 3}, {x: 4, y: 3}, {x: 4, y: 3}, {x: 3, y: 3}, {x: 2, y: 3}, {x: 1, y:3}];
              const battery100array = [{x: 0, y: 0}, {x: 1, y: 0}, {x: 2, y: 0}, {x: 3, y: 0}, {x: 4, y: 0}, {x: 5, y: 0}, {x: 0, y: 1}, {x: 6, y: 1}, {x: 0, y: 2}, {x: 6, y: 2}, {x: 6, y: 2}, {x: 0, y: 3}, {x: 6, y: 3}, {x: 0, y: 4}, {x: 1, y: 4}, {x: 2, y: 4}, {x: 3, y: 4}, {x: 4, y: 4}, {x: 5, y: 4}]; 
              const allNumArray = [zeroArray, oneArray, twoArray, threeArray, fourArray, fiveArray, sixArray, sevenArray, eightArray, nineArray, delimArray, middleArray, battery100array];
              const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
              let timer_StopVibrate = null;	 
              const deviceInfo = hmSetting.getDeviceInfo();
              if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
              if (!weatherSensor) weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
              let screenType = hmSetting.getScreenType();

              const numCoordArray = [{mx : multX, my: multY, x: X1, y: y0, color: 0, aod: true},
                {mx : multX, my: multY, x: X2, y: y0, color: 0, aod: true },
                {mx : multX, my: multY, x: X3, y: y0, color: 0, aod: true},
                {mx : multX, my: multY, x: X4, y: y0, color: 0, aod: true},
                {mx : multXsec, my: multYsec, x: X5, y: y1, color: 1, aod: false},
                {mx : multXsec, my: multYsec, x: X6, y: y1, color: 1, aod: false},
                {mx : multXsec, my: multYsec, x: X7, y: y0 + 20, color: 1, aod: true}]

              let HourTens = parseInt(timeSensor.hour / 10)
              let HourOnes = parseInt(timeSensor.hour % 10)
              let MinuteTens = parseInt(timeSensor.minute / 10)
              let MinuteOnes = parseInt(timeSensor.minute % 10);
              let SecondTens = parseInt(timeSensor.second / 10);
              let SecondOnes = parseInt(timeSensor.second % 10);
              let updateArray = [{num: 0, update:false, oldNum: HourTens},
                {num: 0, update: false, oldNum: HourOnes},
                {num: 0, update: false, oldNum: MinuteTens},
                {num: 0, update: false, oldNum: MinuteOnes},
                {num: 0, update: false, oldNum: SecondTens},
                {num: 0, update: false, oldNum: SecondOnes},
                {num: 10, update: false, oldNum: 10}]

                function scale_call() {
                  console.log('scale_call()');
    
                    console.log('update scales BATTERY');
                    
                    let valueBattery = battery.current;
                    let targetBattery = 100;
                    let progressBattery = valueBattery/targetBattery;
                    if (progressBattery > 1) progressBattery = 1;
                    let progress_ls_normal_battery = progressBattery;
    
                    if (screenType != hmSetting.screen_type.AOD) {
    
                      // normal_battery_linear_scale
                      // initial parameters
                      let start_x_normal_battery = 84;
                      let start_y_normal_battery = 0;
                      let lenght_ls_normal_battery = 310;
                      let line_width_ls_normal_battery = 55;
                      let color_ls_normal_battery = 0xFF43CC77; // 808000 43CC77
                      
                      // calculated parameters
                      let start_x_normal_battery_draw = start_x_normal_battery;
                      let start_y_normal_battery_draw = start_y_normal_battery;
                      lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                      let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                      let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                      if (lenght_ls_normal_battery < 0){
                        lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                        start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                      };
                      
                      normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                        x: start_x_normal_battery_draw,
                        y: start_y_normal_battery_draw,
                        w: lenght_ls_normal_battery_draw,
                        h: line_width_ls_normal_battery_draw,
                        color: color_ls_normal_battery,
                      });
                    };
    
                };

              function isDay(iconSet = false){
                let weatherData = weatherSensor.getForecastWeather();		
                let tideData = weatherData.tideData;
                let tideDataElement = tideData.data[0];
                let sunrise = tideDataElement.sunrise;
                let sunset = tideDataElement.sunset;
                let angleTime = timeSensor.hour * 30 + timeSensor.minute /2;
                let angleSunrise = sunrise.hour * 30 + sunrise.minute /2;
                let angleSunset = sunset.hour * 30 + sunset.minute /2; 
                if (iconSet) {
                  sunriseIMG.setProperty(hmUI.prop.VISIBLE, false);
                  sunsetIMG.setProperty(hmUI.prop.VISIBLE, false);
                  if ((angleTime >= angleSunrise) && (angleTime <= (angleSunrise + sunDelta))) {
                  //if ((timeSensor.hour == sunrise.hour) && (timeSensor.minute == sunrise.minute)) {
                    sunriseIMG.setProperty(hmUI.prop.VISIBLE, true);
                  }
                  if ((angleTime >= angleSunset) && (angleTime <= (angleSunset + sunDelta))) {
                  //if ((timeSensor.hour == sunset.hour) && (timeSensor.minute == sunset.minute)) {
                    sunsetIMG.setProperty(hmUI.prop.VISIBLE, true);
                  }
                }
                if (((angleTime >= angleSunrise) && (angleTime < angleSunset))) return 1;
                return 0;
              }

              function switchVibroOptions(){
                let options = ['Оповещения отключены','Только о разрыве', 'Только ежечасные', 'Оповещения включены']
                vibroOptions++;
                vibroOptions = vibroOptions % 4;
                hmFS.SysProSetInt('vibro_letsmove', vibroOptions);
                hmUI.showToast({text: options[vibroOptions]});
                vibro();
              }
              
              function switchSkin(increment) {		
                let color;
                if (isDay(false) == 1) {
                  if (increment != 0) {
                    dotColorDay+= increment;
                    if (dotColorDay < 0) {dotColorDay = maxColor - 1} else {dotColorDay = dotColorDay % maxColor}
                    hmFS.SysProSetInt('dotcolor_letsmove', dotColorDay);
                    hmUI.showToast({text: 'Дневной вид'});
                    vibro();
                  }
                  color = dotColorDay;
                } else {
                  if (increment != 0) {
                    dotColorNight+= increment;
                    if (dotColorNight < 0) {dotColorNight = maxColor - 1} else {dotColorNight = dotColorNight % maxColor}
                    hmFS.SysProSetInt('dotcolorn_letsmove', dotColorNight);
                    hmUI.showToast({text: 'Ночной вид'});
                    vibro();
                  }
                  color = dotColorNight;
                }
                return color;
              };	     
              
              function vibro(scene = 28) {
                let stopDelay = 200;
                stopVibro();
                vibrate.stop();
                vibrate.scene = scene;
                if(scene < 23 || scene > 25) stopDelay = 1220;
                vibrate.start();
                timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibro, {});
              };
          
              function stopVibro(){
                vibrate.stop();
                if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
              }         
              
              function repeat_alerts() {
                if(timeSensor.minute == 0) {
                  if (vibroOptions > 1) {
                    vibro(5);
                  }
                }
              };
      
              function numtoCord(numArray, multX, multY, offsetX, offsetY, vector) {
                let nArray = [{x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}];
                for (let i = 0; i < 19; i++) {
                  nArray[i].x = (numArray[i].x + vector[i].x * frame) * multX + offsetX;
                  nArray[i].y = (numArray[i].y + vector[i].y * frame) * multY + offsetY;
                }
                return nArray;
              };
      
              function CheckTime(force = false){
                aodScreen = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
                let tempDotColor = dotColor;
                dotColor = switchSkin(0);
                if (tempDotColor != dotColor) force = true;
                let needUpdate = false;
                let tempHourTens = parseInt(timeSensor.hour / 10)
                let tempHourOnes = parseInt(timeSensor.hour % 10)
                let tempMinuteTens = parseInt(timeSensor.minute / 10)
                let tempMinuteOnes = parseInt(timeSensor.minute % 10);
                let tempSecondTens = parseInt(timeSensor.second / 10);
                let tempSecondOnes = parseInt(timeSensor.second % 10);
                if (!force) {
                  updateArray[0].num = tempHourTens;
                  updateArray[1].num = tempHourOnes;
                  updateArray[2].num = tempMinuteTens;
                  updateArray[3].num = tempMinuteOnes;
                  if (!aodScreen) {
                    updateArray[4].num = tempSecondTens;
                    updateArray[5].num = tempSecondOnes;
                  } else {
                    updateArray[4].num = tempSecondTens;
                    updateArray[5].num = tempSecondOnes;
                    updateArray[4].oldNum = tempSecondTens;
                    updateArray[5].oldNum = tempSecondOnes;
                  }
                } else {
                  needUpdate = true;
                  for (let i = 0; i < screenSimbols; i++) updateArray[i].update = true;
                  updateArray[0].num = tempHourTens;
                  updateArray[1].num = tempHourOnes;
                  updateArray[2].num = tempMinuteTens;
                  updateArray[3].num = tempMinuteOnes;
                  updateArray[4].num = tempSecondTens;
                  updateArray[5].num = tempSecondOnes;
                  updateArray[0].oldNum = tempHourTens;
                  updateArray[1].oldNum = tempHourOnes;
                  updateArray[2].oldNum = tempMinuteTens;
                  updateArray[3].oldNum = tempMinuteOnes;
                  updateArray[4].oldNum = tempSecondTens;
                  updateArray[5].oldNum = tempSecondOnes;
                }                
                // расчитаем все векторы, которые требуют обновления
                for (let i = 0; i < screenSimbols; i++) {
                    if (updateArray[i].num != updateArray[i].oldNum) {
                      updateArray[i].update = true;
                      needUpdate = true;
                      let startArray = allNumArray[updateArray[i].oldNum];
                      let endArray = allNumArray[updateArray[i].num];
                      let nArray = [{x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}];
                      for (let k = 0; k < 19; k++) {
                        nArray[k].x = (endArray[k].x - startArray[k].x) / maxFrame;
                        nArray[k].y = (endArray[k].y - startArray[k].y) / maxFrame;
                      }
                      numsVector[i] = nArray;
                    }
                }
                if (needUpdate) {
                  if (force) {
                    for (let i = 0; i < screenSimbols; i++)  {
                      numsVector[i] = [{x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}];
                      drawNum(allNumArray[updateArray[i].oldNum], i, force);
                    }
                  } else if (!timer1) {
                    frame = 0;
                    timer1 = timer.createTimer(0, frameRate, function (option) {
                      frame++;
                      if (frame < maxFrame) {
                        for (let i = 0; i < screenSimbols; i++) {
                          if (updateArray[i].update) drawNum(allNumArray[updateArray[i].oldNum], i);
                        } 
                      } else {
                        timer.stopTimer(timer1);
                        for (let i = 0; i < screenSimbols; i++) {
                          numsVector[i] = [{x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}, {x: 0.0, y: 0.0}];
                          updateArray[i].oldNum = updateArray[i].num;
                          if (updateArray[i].update) drawNum(allNumArray[updateArray[i].oldNum], i, true);
                          updateArray[i].update = false;
                        }
                        timer1 = undefined;
                      }
                    });
                  }
                };
              }

              function drawNum(numArray, num, force = false) {
                let tempNumArray = numtoCord(numArray, numCoordArray[num].mx, numCoordArray[num].my, numCoordArray[num].x, numCoordArray[num].y, numsVector[num]);
                for (let i = 0; i < 19; i++) {
                  if (force) {
                    timeNums[num][i].setProperty(hmUI.prop.MORE, { pos_x: tempNumArray[i].x, pos_y: tempNumArray[i].y });
                    timeNums[num][i].setProperty(hmUI.prop.SRC, dotColor_ASCIIARRAY[numCoordArray[num].color + dotColor * 2]);
                  } else {
                    if (!((numsVector[num][i].x == 0) && (numsVector[num][i].y ==0))) {
                      timeNums[num][i].setProperty(hmUI.prop.MORE, { pos_x: tempNumArray[i].x, pos_y: tempNumArray[i].y });
                    }
                  }
                };
              }
      
              function checkConnection() {
                if ((vibroOptions == 1) || (vibroOptions == 3)) {
                  console.log('checkConnection()');
                  hmBle.removeListener;
                  hmBle.addListener(function (status) {
                  if(!status) {
                    hmUI.showToast({text: "Связь потеряна"});
                    vibro(9);
                  }
                  if(status) {
                    hmUI.showToast({text: "Связь восстановлена"});
                    vibro(0);
                  }
                  });
              }
              };

              battery.addEventListener(hmSensor.event.CHANGE, function() {
                scale_call();
              });

              timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
                checkConnection();
                repeat_alerts();
                isDay(true);
              });	

              normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                color: '0xFF000000',
                show_level: hmUI.show_level.ONLY_AOD,
              });

              normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                src: 'back.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              

              normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                x: 80, // 145
                y: 90,  // 80
                week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
                week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
                week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                day_startX: 120, // 80
                day_startY: 84, // 80
                day_sc_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
                day_tc_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
                day_en_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
                day_zero: 0,
                day_space: -1,
                day_align: hmUI.align.CENTER_H,
                day_is_character: false,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 195,
                y: 60, // 53
                image_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
                image_length: 29,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 311, // 195
                y: 84,  // 7
                font_array: ["dig_day_0.png","dig_day_1.png","dig_day_2.png","dig_day_3.png","dig_day_4.png","dig_day_5.png","dig_day_6.png","dig_day_7.png","dig_day_8.png","dig_day_9.png"],
                padding: false,
                h_space: -1,
                unit_sc: 'dig_s_deg.png',
                unit_tc: 'dig_s_deg.png',
                unit_en: 'dig_s_deg.png',
                negative_image: 'dig_s_minus.png',
                invalid_image: 'dig_s_minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 220, // 306
                y: 8, // 82
                src: 'ico_bat.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              bat_scale = hmUI.createWidget(hmUI.widget.IMG, {
                x: 84, 
                y: 0,
                src: 'batscale.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                x: 403, // 280
                y: 92,  // 18
                src: 'status_bt.png',
                type: hmUI.system_status.DISCONNECT,
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
              });

              sunriseIMG = hmUI.createWidget(hmUI.widget.IMG, {
                x: 40,
                y: 330,
                src: 'sunrise.png',
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
              });

              sunsetIMG = hmUI.createWidget(hmUI.widget.IMG, {
                x: 400,
                y: 330,
                src: 'sunset.png',
                show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
              });

              if (screenType != hmSetting.screen_type.AOD) {
                normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT); 
                normal_battery_linear_scale.setAlpha(80);
              };

              for (let n = 0; n < screenSimbols; n++) {
                let aod;
                numToDraw = numtoCord(allNumArray[updateArray[n].oldNum], numCoordArray[n].mx, numCoordArray[n].my, numCoordArray[n].x, numCoordArray[n].y, numsVector[n]);
                for (let i = 0; i < 19; i++) {
                  aod = hmUI.show_level.ONLY_NORMAL;
                  if (numCoordArray[n].aod) aod = hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD;
                  timeNums[n][i] = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    center_x: half,
                    center_y: half,
                    pos_x: numToDraw[i].x,
                    pos_y: numToDraw[i].y,
                    angle: 0,
                    src: dotColor_ASCIIARRAY[numCoordArray[n].color + dotColor * 2],
                    show_level: aod,
                  });
                };
              }

              function onDigitalCrown() {
                hmApp.registerSpinEvent(function (key, degree) {
                    //hmUI.showToast({ text: `degree = ${degree}` })
                    if (key === hmApp.key.HOME) {
                      degreeSum += degree;
                      if (Math.abs(degreeSum) > crownSensitivity){
                        if (degreeSum > 0) {
                          switchSkin(1);
                        } else {
                          switchSkin(-1);
                        };
                        CheckTime(true);
                        degreeSum = 0;
                      }
                    }
                  }
                ) // crown
              };

              Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 210,
                y: 210,
                w: 60,
                h: 60,
                text: '',
                color: 0xFFFF8C00,
                text_size: 25,
                press_src: 'empty.png',
                normal_src: 'empty.png',
                click_func: (button_widget) => {
                  switchVibroOptions();
                  // switchSkin(true);
                  // CheckTime(true);
                }, // end func
                show_level: hmUI.show_level.ONLY_NORMAL,
              }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                isDay(true);
                CheckTime(true);
                checkConnection();
                stopVibro();	
                if (!timer0) timer0 = timer.createTimer( 0, 1000, function () { CheckTime() })
                setTimeout(() => {
                  onDigitalCrown();
                }, 350);
                scale_call();
                //hmUI.showToast({text: 'resume'});              
              }),
              pause_call: (function () {
                console.log('pause_call()');
                hmApp.unregisterSpinEvent();
                //hmUI.showToast({text: 'pause'});
                if (timer0) {
                  timer.stopTimer(timer0);
                  timer0 = undefined;
                }
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
                loadSettings();
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
              if (timer0) {
                timer.stopTimer(timer0);
                timer0 = undefined;
              }
              if (timer1) {
                timer.stopTimer(timer1);
                timer1 = undefined;
              }
              hmApp.unregisterSpinEvent();
              logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}